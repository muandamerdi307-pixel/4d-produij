import 'package:flutter/material.dart';

void main() => runApp(const FourDApp());

const electricBlue = Color(0xFF168BFF);
const navy = Color(0xFF07111F);
const panel = Color(0xFF101F32);

class FourDApp extends StatelessWidget {
  const FourDApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '4D PRODUIJ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(seedColor: electricBlue, brightness: Brightness.dark),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const PhoneLoginPage(),
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});
  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}
class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phone = TextEditingController();
  @override
  void dispose() { phone.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(26), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 92, height: 92, decoration: BoxDecoration(
          shape: BoxShape.circle, border: Border.all(color: electricBlue, width: 2),
          boxShadow: const [BoxShadow(color: electricBlue, blurRadius: 24)]),
          child: const Icon(Icons.public, size: 56, color: electricBlue)),
        const SizedBox(height: 20),
        const Text('4D PRODUIJ', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
        const SizedBox(height: 6),
        const Text('LE MONDE DU DIVERTISSEMENT', style: TextStyle(color: electricBlue, fontSize: 11, letterSpacing: 1.5)),
        const SizedBox(height: 42),
        const Align(alignment: Alignment.centerLeft, child: Text('Bienvenue !', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerLeft, child: Text('Connecte-toi avec ton numéro de téléphone.')),
        const SizedBox(height: 22),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(
          prefixIcon: Icon(Icons.phone_android), hintText: '+243 000 000 000', labelText: 'Numéro de téléphone')),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, height: 52, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: electricBlue),
          onPressed: () {
            if (phone.text.trim().length < 6) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Entre un numéro de téléphone valide.')));
              return;
            }
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
          },
          child: const Text('Continuer', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)))),
        const SizedBox(height: 14),
        const Text('Prototype : aucun SMS de vérification n’est envoyé dans cette version.', textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white54, fontSize: 11)),
      ],
    )))),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [FeedPage(), DiscoverPage(), CreatePage(), LivePage(), ProfilePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: navy, titleSpacing: 18,
      title: const Row(children: [Icon(Icons.public, color: electricBlue), SizedBox(width: 9),
        Text('4D PRODUIJ', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1))]),
      actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('La messagerie sera disponible dans une prochaine version.'))),
        icon: const Icon(Icons.notifications_none)), const SizedBox(width: 6)],
    ),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      backgroundColor: const Color(0xFF0B1929), indicatorColor: electricBlue.withOpacity(.22),
      selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
        NavigationDestination(icon: Icon(Icons.public), label: 'Découvrir'),
        NavigationDestination(icon: Icon(Icons.add_circle_outline, size: 29), label: 'Créer'),
        NavigationDestination(icon: Icon(Icons.live_tv_outlined), label: 'LIVE'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
      ],
    ),
  );
}

class FeedPage extends StatelessWidget {
  const FeedPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('À la une', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 5),
    const Text('Découvre les vidéos de la communauté.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    const StoryCard(name: 'Créateur 4D', caption: 'Bienvenue sur 4D PRODUIJ 🌐', icon: Icons.movie_creation_outlined),
    const StoryCard(name: 'Communauté', caption: 'Partage tes talents avec le monde.', icon: Icons.people_outline),
    const StoryCard(name: 'Découverte', caption: 'De nouveaux contenus arrivent bientôt.', icon: Icons.explore_outlined),
  ]);
}

class StoryCard extends StatelessWidget {
  final String name, caption; final IconData icon;
  const StoryCard({super.key, required this.name, required this.caption, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 16), padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20),
      border: Border.all(color: electricBlue.withOpacity(.25))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [CircleAvatar(backgroundColor: electricBlue.withOpacity(.2), child: Icon(icon, color: electricBlue)),
        const SizedBox(width: 10), Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        const Spacer(), const Icon(Icons.more_horiz)]),
      const SizedBox(height: 16),
      Container(height: 190, width: double.infinity, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(
          colors: [Color(0xFF102F53), Color(0xFF050A12)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: const Center(child: Icon(Icons.play_circle_fill, size: 66, color: electricBlue))),
      const SizedBox(height: 12), Text(caption),
      const SizedBox(height: 12),
      const Row(children: [Icon(Icons.favorite_border), SizedBox(width: 7), Text('J’aime'),
        SizedBox(width: 24), Icon(Icons.mode_comment_outlined), SizedBox(width: 7), Text('Commenter'),
        Spacer(), Icon(Icons.share_outlined)]),
    ]),
  );
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Découvrir 🌐', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
    const SizedBox(height: 16),
    const TextField(decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher des créateurs')),
    const SizedBox(height: 22),
    const Text('Explorer les communautés', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    for (final item in ['Afrique', 'Europe', 'Amérique', 'Asie'])
      Card(color: panel, child: ListTile(leading: const Icon(Icons.public, color: electricBlue),
        title: Text(item), subtitle: const Text('Découvre les créateurs et leurs contenus'),
        trailing: const Icon(Icons.chevron_right))),
  ]);
}

class CreatePage extends StatelessWidget {
  const CreatePage({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(26), child: Column(
    mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.video_camera_back_outlined, size: 76, color: electricBlue),
      const SizedBox(height: 18), const Text('Créer une vidéo', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), const Text('Prépare et partage tes meilleurs moments sur 4D PRODUIJ.', textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('L’ajout de vidéos sera activé avec le module de stockage.'))),
        icon: const Icon(Icons.add), label: const Text('Ajouter une vidéo')),
    ],
  )));
}

class LivePage extends StatelessWidget {
  const LivePage({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(26), child: Column(
    mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.live_tv, size: 78, color: electricBlue),
      const SizedBox(height: 18), const Text('4D LIVE', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10), const Text('Le direct est réservé aux comptes ayant au moins 1 000 abonnés.',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
        child: const Column(children: [Text('0 / 1 000', style: TextStyle(fontSize: 25, color: electricBlue, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), LinearProgressIndicator(value: 0, color: electricBlue, backgroundColor: Colors.white12),
          SizedBox(height: 8), Text('Abonnés requis pour demander l’accès') ])),
      const SizedBox(height: 18), const Text('Le streaming en direct sera connecté au serveur dans une prochaine version.',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)),
    ],
  )));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 20),
    const Center(child: CircleAvatar(radius: 48, backgroundColor: Color(0xFF123B63),
      child: Icon(Icons.person, size: 54, color: electricBlue))),
    const SizedBox(height: 14),
    const Center(child: Text('Mon profil', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
    const Center(child: Text('@createur4d', style: TextStyle(color: Colors.white54))),
    const SizedBox(height: 24),
    const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      Stat(value: '0', label: 'Vidéos'), Stat(value: '0', label: 'Abonnés'), Stat(value: '0', label: 'Abonnements')]),
    const SizedBox(height: 24),
    for (final item in [
      [Icons.person_outline, 'Modifier mon profil'],
      [Icons.card_giftcard, 'Mes cadeaux'],
      [Icons.verified_outlined, 'Certification du compte'],
      [Icons.settings_outlined, 'Paramètres'],
    ]) Card(color: panel, child: ListTile(leading: Icon(item[0] as IconData, color: electricBlue),
      title: Text(item[1] as String), trailing: const Icon(Icons.chevron_right),
      onTap: () => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${item[1]} : module à connecter.'))))),
  ]);
}

class Stat extends StatelessWidget {
  final String value, label;
  const Stat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: electricBlue)),
    Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
  ]);
}
